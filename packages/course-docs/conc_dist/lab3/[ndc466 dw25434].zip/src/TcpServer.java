import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer extends Thread {
	
    private ServerSocket listener;
    private Socket socket;
    private Store store;
    
    TcpServer(int port, Store store) {
      this.store = store;

      try {
        this.listener = new ServerSocket(port);
      } catch (IOException e) {
    	  e.printStackTrace();
    	  System.exit(-1);
      }
    }

    @Override
    public void run() {
      try {
        while ( (socket = listener.accept()) != null) {
          Thread t = new Thread(new TcpThread(store, socket));
          t.start();
        } 
      } catch (IOException e) {
        e.printStackTrace();
        return;
      }
    }
  }
