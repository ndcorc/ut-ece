import java.io.PrintStream;
import java.util.Scanner;
import java.util.NoSuchElementException;

public class TcpClient {
	
	private PrintStream pout;
	private Scanner din;
	private String output;
	
	public TcpClient(PrintStream pout, Scanner din) {
		this.pout = pout;
		this.din = din;
	}
	
	public void execute(String cmd){
	    pout.println(cmd);
	    pout.flush();

	    try {
		    while ((output = din.nextLine()) != null) {
		      if (output.equals("done")) break;
		      System.out.println(output);
		    }
		} catch (NoSuchElementException e) {
			System.out.println("\nLost connection to the server...exiting");
			System.exit(-1);
		}

	}
}
